#ifndef _substitute_h_INCLUDED
#define _substitute_h_INCLUDED

#include "kissat_bool.h"

struct kissat;

void kissat_substitute (struct kissat *, bool first);

#endif
