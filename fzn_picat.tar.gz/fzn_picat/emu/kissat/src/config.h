#ifndef NOPTIONS
#ifndef _config_h_INCLUDED
#define _config_h_INCLUDED

#include "kissat_bool.h"

struct kissat;

void kissat_configuration_usage (void);
bool kissat_has_configuration (const char *);

#endif
#endif
